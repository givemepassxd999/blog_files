package example.givemepass.threadpooldemo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class MainActivity extends AppCompatActivity {
    private Button sendInvokeAll;
    private Button sendInvokeAny;
    private TextView result;
    private List<Callable<String>> tasks;
    private StringBuffer strBuffer;
    private ExecutorService executorService;
    private final static int INVOTE_ALL = 0;
    private final static int INVOTE_ANY = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initData();
        initView();
    }
    private void initView(){
        sendInvokeAll = (Button) findViewById(R.id.invoke_all);
        sendInvokeAny = (Button) findViewById(R.id.invoke_any);
        result = (TextView) findViewById(R.id.result);
        sendInvokeAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                executeTask(INVOTE_ALL);
            }
        });
        sendInvokeAny.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                executeTask(INVOTE_ANY);
            }
        });
    }
    private void initData(){
        tasks = new ArrayList<>();
        strBuffer = new StringBuffer();
        executorService = Executors.newCachedThreadPool();
    }
    private String emulateGetStringFromServer(int index){
        String string = "task ";
        try {
            int r = (int)(Math.random() * 3 + 1);
            Thread.sleep(r * 1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return string + index + " is done.";
    }
    private void executeTask(final int flag){
        new Thread(new Runnable() {
            @Override
            public void run() {

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tasks.clear();
                        strBuffer.delete(0, strBuffer.length());
                        strBuffer.append("Loding..." + "\n");
                        result.setText(strBuffer.toString());
                    }
                });
                tasks.add(new Callable<String>() {
                    @Override
                    public String call() throws Exception {
                        return emulateGetStringFromServer(1);
                    }
                });
                tasks.add(new Callable<String>() {
                    @Override
                    public String call() throws Exception {
                        return emulateGetStringFromServer(2);
                    }
                });
                try {

                    if(flag == INVOTE_ALL) {
                        List<Future<String>> futures = executorService.invokeAll(tasks);
                        for(int i = 0; i < futures.size(); i++){
                            strBuffer.append(futures.get(i).get() + "\n");
                        }
                    } else {
                        String taskStr = executorService.invokeAny(tasks);
                        strBuffer.append(taskStr);
                    }

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            result.setText(strBuffer.toString());
                        }
                    });
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
}
