package example.givemepass.connecttophp_upload;

import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button upload;
    private TextView resMsg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        upload = (Button) findViewById(R.id.upload);
        resMsg = (TextView) findViewById(R.id.msg);
        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        FileUpload mFileUpload = new FileUpload();
                        mFileUpload.setOnFileUploadListener(new FileUpload.OnFileUploadListener() {
                            @Override
                            public void onFileUploadSuccess(final String msg) {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        resMsg.setText(msg);
                                    }
                                });

                            }

                            @Override
                            public void onFileUploadFail(final String msg) {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        resMsg.setText(msg);
                                    }
                                });
                            }
                        });
                        mFileUpload.doFileUpload(Environment.getExternalStorageDirectory().getAbsolutePath() + "/DCIM/butterfly.png");
                    }
                }).start();
            }
        });
    }

}
