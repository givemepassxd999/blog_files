package example.givemepass.activityforresultdemo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class OtherActivity extends AppCompatActivity {
    private EditText otherActivityEditText;
    private Button startActivityForResultBack;
    public static final String FLAG = "BACK_STRING";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_other);
        otherActivityEditText = (EditText) findViewById(R.id.other_activtity_edittext);
        startActivityForResultBack = (Button) findViewById(R.id.start_activity_for_result_back);

        startActivityForResultBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                Bundle b = new Bundle();
                b.putString(FLAG, otherActivityEditText.getText().toString());
                intent.putExtras(b);
                OtherActivity.this.setResult(RESULT_OK, intent);
                finish();
            }
        });
    }
}
