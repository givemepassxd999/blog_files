package com.example.givemepass.eventbusdemo;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.givemepass.testeventbus.R;

import de.greenrobot.event.EventBus;

/**
 * Created by givemepass on 2015/6/19.
 */
public class SampleDialog extends Dialog{

	private Context context;

	private Button sendBtn;

	private EditText editText;

	private EventBus mEventBus;

	public SampleDialog(Context context) {
		super(context, android.R.style.Theme_Light);
		this.context = context;

		mEventBus = EventBus.getDefault();
		setContentView(R.layout.dialog_layout);
		sendBtn = (Button) findViewById(R.id.send_button);
		editText = (EditText) findViewById(R.id.edit_text);
		sendBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				MyEvent event = new MyEvent();
				event.setMyEventString(editText.getText().toString());
				mEventBus.post(event);
				dismiss();
			}
		});
	}
}
