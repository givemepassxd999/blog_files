package com.example.givemepass.eventbusdemo;

/**
 * Created by givemepass on 2015/6/19.
 */
public class MyEvent {
	private String myEventString;

	public String getMyEventString() {
		return myEventString;
	}

	public void setMyEventString(String myEventString) {
		this.myEventString = myEventString;
	}
}
