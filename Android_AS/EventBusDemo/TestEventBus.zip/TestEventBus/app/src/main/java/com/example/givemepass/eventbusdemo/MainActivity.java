package com.example.givemepass.eventbusdemo;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.givemepass.testeventbus.R;

import de.greenrobot.event.EventBus;


public class MainActivity extends Activity {

	private EventBus eventBus;

	private TextView textView;

	private Button mShowDialog;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		textView = (TextView) findViewById(R.id.text);
		mShowDialog = (Button) findViewById(R.id.show_btn);
		mShowDialog.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				new SampleDialog(MainActivity.this).show();
			}
		});
		eventBus = EventBus.getDefault();
		eventBus.register(this);
	}

	public void onEventMainThread(MyEvent event){
		textView.setText(event.getMyEventString());
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		eventBus.unregister(this);
	}
}
