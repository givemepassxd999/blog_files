package personal.givemepass.autocompletetextviewdemo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

public class MainActivity extends AppCompatActivity {
	private String[] vocabulary = {
			"apple", "application", "appal", "appalachia", "apposite"
	};
	private ArrayAdapter<String> adapter;
	private AutoCompleteTextView textView;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		adapter = new ArrayAdapter<>(this,
			android.R.layout.simple_dropdown_item_1line,
			vocabulary);

		textView = (AutoCompleteTextView) findViewById(R.id.auto_complete_text);
		textView.setThreshold(1);
		textView.setAdapter(adapter);
	}
}
