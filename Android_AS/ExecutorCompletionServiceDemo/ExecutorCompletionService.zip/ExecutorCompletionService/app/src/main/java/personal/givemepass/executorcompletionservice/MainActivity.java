package personal.givemepass.executorcompletionservice;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
	private Button startTask;
	private TextView result;
	private CompletionService<String> completionService;
	private ExecutorService executorService;
	private StringBuffer strBuffer;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		initData();
		initView();
	}

	private void initData(){
		executorService = Executors.newCachedThreadPool();
		completionService = new ExecutorCompletionService<String>(executorService);
		strBuffer = new StringBuffer();
	}

	private void initView(){
		startTask = (Button) findViewById(R.id.start_task);
		result = (TextView) findViewById(R.id.result);
		startTask.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				ExecutorService singleThread = Executors.newSingleThreadExecutor();
				singleThread.submit(new Runnable() {
					@Override
					public void run() {
						strBuffer.delete(0, strBuffer.length());
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								result.setText(strBuffer.toString());
							}
						});
						for(int i = 0; i < 10; i++) {
							completionService.submit(getTask(i));
						}
						for(int i = 0; i < 10; i++) {
							try {
								String s = completionService.take().get();
								strBuffer.append(s + "\n");
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										result.setText(strBuffer.toString());
									}
								});

							} catch (InterruptedException e) {
								e.printStackTrace();
							} catch (ExecutionException e) {
								e.printStackTrace();
							}
						}
					}
				});

			}
		});
	}

	private Callable<String> getTask(final int index){
		return new Callable<String>() {
			@Override
			public String call() throws Exception {
				int r = (int)(Math.random() * 3 + 1);
				Thread.sleep(r * 1000);
				return "task " + index;
			}
		};
	}
}
