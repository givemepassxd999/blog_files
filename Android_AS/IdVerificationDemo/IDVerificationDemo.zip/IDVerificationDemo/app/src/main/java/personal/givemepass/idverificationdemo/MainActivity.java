package personal.givemepass.idverificationdemo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

	private Button checkId;
	private EditText inputId;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		checkId = (Button)findViewById(R.id.check_id_number);
		inputId = (EditText)findViewById(R.id.input_id_number);
		checkId.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View arg0) {
				if (checkCardId(inputId.getText().toString())) {
					Toast.makeText(MainActivity.this, "身分證字號正確", Toast.LENGTH_SHORT).show();
				} else {
					Toast.makeText(MainActivity.this, "身分證字號錯誤,請檢查!", Toast.LENGTH_SHORT).show();
				}
			}
		});

	}

	//檢查身分證字號
	private boolean checkCardId(String id) {
		if (!id.matches("[a-zA-Z][1-2][0-9]{8}")) {
			return false;
		}

		String newId = id.toUpperCase();
		//身分證第一碼代表數值
		int[] headNum = new int[]{
				1, 10, 19, 28, 37,
				46, 55, 64, 39, 73,
				82, 2, 11, 20, 48,
				29, 38, 47, 56, 65,
				74, 83, 21, 3, 12, 30};

		char[] headCharUpper = new char[]{
				'A', 'B', 'C', 'D', 'E', 'F', 'G',
				'H', 'I', 'J', 'K', 'L', 'M', 'N',
				'O', 'P', 'Q', 'R', 'S', 'T', 'U',
				'V', 'W', 'X', 'Y', 'Z'
		};

		int index = Arrays.binarySearch(headCharUpper, newId.charAt(0));
		int base = 8;
		int total = 0;
		for (int i = 1; i < 10; i++) {
			int tmp = Integer.parseInt(Character.toString(newId.charAt(i))) * base;
			total += tmp;
			base--;
		}

		total += headNum[index];
		int remain = total % 10;
		int checkNum = (10 - remain) % 10;
		if (Integer.parseInt(Character.toString(newId.charAt(9))) != checkNum) {
			return false;
		}
		return true;
	}
}
