package example.givemepass.toolbarmenudemo;

import android.app.Dialog;
import android.content.Context;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

public class MyDialog extends Dialog{
    private Toolbar mToolbar;
    private Context mContext;
    public MyDialog(Context context) {
        super(context, R.style.MyDialogTheme);
        setContentView(R.layout.my_dialog);
        mContext = context;
        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        mToolbar.setTitle("Toolbar Demo");
        mToolbar.setNavigationIcon(R.drawable.ic_keyboard_arrow_left_24dp);
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
        mToolbar.inflateMenu(R.menu.menu_layout);
        mToolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()){
                    case R.id.menu_edit:
                        Toast.makeText(mContext, "Edit is clicked!", Toast.LENGTH_SHORT).show();
                        break;
                }
                return false;
            }
        });
    }
}
