package example.givemepass.handlerthreaddemo;

import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button shortTask;
    private Button longTask;
    private TextView taskResult;
    private HandlerThread mHandlerThread;
    private Handler mHandler;
    private StringBuffer strBuffer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initData();
        initView();
    }
    private void initData(){
        mHandlerThread = new HandlerThread("handler thread");
        mHandlerThread.start();
        mHandler = new Handler(mHandlerThread.getLooper());
        strBuffer = new StringBuffer();
    }
    private void initView(){

        shortTask = (Button) findViewById(R.id.short_task);
        longTask = (Button) findViewById(R.id.long_task);
        taskResult = (TextView) findViewById(R.id.result);
        shortTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        strBuffer.append("short task \n");
                        updateView();
                    }
                });
            }
        });
        longTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        strBuffer.append("wait long task...");
                        updateView();
                        try {
                            Thread.sleep(2000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        strBuffer.append("done\n");
                        updateView();
                    }
                });
            }
        });
    }
    private void updateView(){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                taskResult.setText(strBuffer.toString());
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mHandlerThread.quit();
    }
}
