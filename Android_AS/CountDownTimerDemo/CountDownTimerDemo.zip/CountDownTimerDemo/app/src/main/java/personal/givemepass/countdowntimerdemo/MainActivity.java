package personal.givemepass.countdowntimerdemo;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
	private TextView mTextView;
	private Button start;
	private CountDownTimer mCountDownTimer;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		mTextView = (TextView)findViewById(R.id.text_view);
		mCountDownTimer = new CountDownTimer(30000,1000){

			@Override
			public void onFinish() {
				mTextView.setText("Done!");
			}

			@Override
			public void onTick(long millisUntilFinished) {
				mTextView.setText("seconds remaining:"+millisUntilFinished/1000);
			}

		};

		start = (Button) findViewById(R.id.start_count_down);
		start.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				mCountDownTimer.start();
			}
		});
	}
}
