package com.example.dialogdemo;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity {

	private Button showDialog;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        showDialog = (Button) findViewById(R.id.show_dialog);
        
        showDialog.setOnClickListener(new OnClickListener() {
            
            @Override
            public void onClick(View v) {
                new MyDialog(MainActivity.this).show();
            }
        });
        
    } 
}
