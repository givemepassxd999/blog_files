package personal.givemepass.progressdialogdemo;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

	private Dialog dialog;
	private Button waitButton;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		waitButton = (Button)findViewById(R.id.waitButton);
		waitButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View arg0) {
				dialog = ProgressDialog.show(MainActivity.this,
						"讀取中", "請等待3秒...", true);
				new Thread(new Runnable() {
					@Override
					public void run() {
						try {
							Thread.sleep(3000);
						} catch (Exception e) {
							e.printStackTrace();
						} finally {
							dialog.dismiss();
						}
					}
				}).start();
			}
		});
	}
}
