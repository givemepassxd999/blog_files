package example.givemepass.messengerremotedemo;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;

public class RemoteService extends Service {
    private Messenger mMessenger;
    private HandlerThread mHandlerThread;
    private Handler mHandler;
    @Override
    public void onCreate() {
        super.onCreate();
        mHandlerThread = new HandlerThread("remote service");
        mHandlerThread.start();
        mHandler = new Handler(mHandlerThread.getLooper()){
            @Override
            public void handleMessage(Message msg) {
                try {
                    int rand = (int) Math.random()*3 + 1;
                    Thread.sleep(rand * 1000);
                    int what = msg.what;
                    Bundle b = new Bundle();
                    b.putString("remote", "task " + what + " is done\n");
                    Message m = new Message();
                    m.setData(b);
                    msg.replyTo.send(m);
                } catch (RemoteException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };
        mMessenger = new Messenger(mHandler);
    }

    @Override
    public void onDestroy() {
        mHandlerThread.quit();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mMessenger.getBinder();
    }
}
