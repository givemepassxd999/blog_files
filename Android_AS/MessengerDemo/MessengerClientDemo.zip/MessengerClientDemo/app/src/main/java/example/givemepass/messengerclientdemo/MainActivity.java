package example.givemepass.messengerclientdemo;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button connectRemote;
    private Button disconnectRemote;
    private ServiceConnection mServiceConnection;
    private Messenger messenger;
    private boolean isBound;
    private TextView result;
    private StringBuffer sb;
    private int index = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initData();
        initView();
    }

    private void clearText(String msg){
        sb.delete(0, sb.length());
        if(msg != null) {
            sb.append(msg);
            sb.append("\n");
        }
        result.setText(sb);
    }

    private void initData(){
        sb = new StringBuffer();
    }

    private void initView(){
        result = (TextView) findViewById(R.id.result);
        connectRemote = (Button) findViewById(R.id.connect_remote);
        disconnectRemote = (Button) findViewById(R.id.disconnect_remote);
        connectRemote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!isBound) {
                    clearText(null);
                    mServiceConnection = new ServiceConnection() {
                        @Override
                        public void onServiceConnected(ComponentName name, IBinder service) {
                            messenger = new Messenger(service);
                            isBound = true;
                            clearText("remote is connected");
                        }

                        @Override
                        public void onServiceDisconnected(ComponentName name) {
                            messenger = null;
                            isBound = false;
                            clearText("remote is disconnected.");
                        }
                    };
                    Intent intent = new Intent();
                    intent.setAction("service.remote");
                    intent.setPackage("example.givemepass.messengerremotedemo");
                    bindService(intent, mServiceConnection, Context.BIND_AUTO_CREATE);
                } else{
                    try {
                        Message m = new Message();
                        m.what = index;
                        m.replyTo = new Messenger(new Handler(getMainLooper()){
                            @Override
                            public void handleMessage(Message msg) {
                                String msgStr = msg.getData().getString("remote");
                                if(msgStr != null){
                                    sb.append(msgStr);
                                    result.setText(sb);
                                }
                            }
                        });
                        messenger.send(m);
                    } catch (RemoteException e) {
                        e.printStackTrace();
                    }
                    index++;
                }
            }
        });
        disconnectRemote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                messenger = null;
                isBound = false;
                index = 1;
                clearText("remote is disconnected.");
            }
        });
    }
}
