package example.givemepass.bindservicedemo;

import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private LoaclServiceConnection mLoaclServiceConnection;
    private MyService mService;
    private Button startService;
    private TextView result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
    }
    private void initView(){
        startService = (Button) findViewById(R.id.start_service);
        result = (TextView) findViewById(R.id.result);
        mLoaclServiceConnection = new LoaclServiceConnection();
        startService.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bindService(new Intent(MainActivity.this, MyService.class), mLoaclServiceConnection, Service.BIND_AUTO_CREATE);
            }
        });
    }

    private class LoaclServiceConnection implements ServiceConnection {

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            //透過Binder調用Service內的方法
            mService = ((MyService.MyBinder)service).getService();
            String serviceName = mService.getServiceName();
            result.setText("service name is " + serviceName);
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
            //service 物件設為null
            mService = null;
        }
    }
}
