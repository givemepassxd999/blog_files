package com.example.givemepass.dialogdemo2;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

public class MoreDialog extends Dialog {

	private Context mContext;

	private View outSideLayout;

	private OnItemSelectedListener mOnItemSelectedListener;

	public interface OnItemSelectedListener{
		public void OnItemSelected(int pos);
	}

	public void setOnItemSelectedListener(OnItemSelectedListener listener){
		mOnItemSelectedListener = listener;
	}

	private TextView item1, item2, item3, item4, item5;

	public MoreDialog(Context context) {
		super(context, android.R.style.Theme);
		mContext = context;

		getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		requestWindowFeature(Window.FEATURE_NO_TITLE);

		View mainView = LayoutInflater.from(mContext).inflate(R.layout.file_sharing_more, null, false);
		setContentView(mainView);

		outSideLayout = mainView.findViewById(R.id.more_outside_layout);
		outSideLayout.getLayoutParams().height = 2000;
		outSideLayout.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				dismiss();

			}
		});
		item1 = (TextView) findViewById(R.id.file_sharing_add_new_folder);
		item2 = (TextView) findViewById(R.id.file_sharing_upload_file);
		item3 = (TextView) findViewById(R.id.file_sharing_upload_photo);
		item4 = (TextView) findViewById(R.id.file_sharing_upload_video);
		item5 = (TextView) findViewById(R.id.file_sharing_take_picture_or_record);

		item1.setText("Item 1");
		item2.setText("Item 2");
		item3.setText("Item 3");
		item4.setText("Item 4");
		item5.setText("Item 5");

		item1.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				if(mOnItemSelectedListener != null){
					mOnItemSelectedListener.OnItemSelected(0);
				}
				dismiss();
			}
		});
		item2.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				if(mOnItemSelectedListener != null){
					mOnItemSelectedListener.OnItemSelected(1);
				}
				dismiss();
			}
		});
		item3.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				if(mOnItemSelectedListener != null){
					mOnItemSelectedListener.OnItemSelected(2);
				}
				dismiss();
			}
		});
		item4.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				if(mOnItemSelectedListener != null){
					mOnItemSelectedListener.OnItemSelected(3);
				}
				dismiss();
			}
		});
		item5.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				if(mOnItemSelectedListener != null){
					mOnItemSelectedListener.OnItemSelected(4);
				}
				dismiss();
			}
		});
	}


}