package personal.givemepass.downloadmanagerdemo;

import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
	private Button startDownload;
	private Button showImage;
	private ImageView imageView;
	private DownloadManager manager;
	private BroadcastReceiver receiver;
	private static final String url = "https://dl.dropboxusercontent.com/u/24682760/Android_AS/DownloadManagerDemo/butterfly.png";
	private DownloadManager.Request request;
	private long downloadId;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		initData();
		initView();
	}
	private void initData(){
		manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
		receiver = new BroadcastReceiver() {
			@Override
			public void onReceive(Context context, Intent intent) {
				String action = intent.getAction();
				if(DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(action)){
					DownloadManager.Query query = new DownloadManager.Query();
					query.setFilterById(downloadId);
					Cursor c = manager.query(query);
					if (c.moveToFirst()) {
						int columnIndex = c.getColumnIndex(DownloadManager.COLUMN_STATUS);
						if (DownloadManager.STATUS_SUCCESSFUL == c.getInt(columnIndex)) {
							String uriString = c.getString(c.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI));
							imageView.setImageURI(Uri.parse(uriString));
							Toast.makeText(MainActivity.this, "download success", Toast.LENGTH_SHORT).show();
						}
					}
				}
			}
		};
		registerReceiver(receiver, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
		request = new DownloadManager.Request(Uri.parse(url));
	}

	private void initView(){
		startDownload = (Button) findViewById(R.id.start_download);
		showImage = (Button) findViewById(R.id.show_image);
		imageView = (ImageView) findViewById(R.id.image);
		startDownload.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				downloadId = manager.enqueue(request);
			}
		});
		showImage.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent();
				i.setAction(DownloadManager.ACTION_VIEW_DOWNLOADS);
				startActivity(i);
			}
		});
	}
}
