package example.givemepass.connecttophp_json;

import com.google.gson.annotations.SerializedName;

public class MyJson {
    @SerializedName("id")
    private String myId;
    @SerializedName("data")
    private String myName;

    public String getMyId() {
        return myId;
    }

    public void setMyId(String myId) {
        this.myId = myId;
    }

    public String getMyName() {
        return myName;
    }

    public void setMyName(String myName) {
        this.myName = myName;
    }
}
