package com.example.givemepass.commanddemo;

import android.widget.TextView;

public class Computer {
    private TextView mDisplayText;
    public Computer(TextView displayText) {
        mDisplayText = displayText;
    }
    public void computerOpen(){
        mDisplayText.setText(mDisplayText.getText() + "\n" + "computer is " + Constant.OPEN_NAME);
    }
    public void computerClose(){
        mDisplayText.setText(mDisplayText.getText() + "\n" + "computer is " + Constant.CLOSE_NAME);
    }
    public void computerStandby(){
        mDisplayText.setText(mDisplayText.getText() + "\n" + "computer is " + Constant.STANDBY_NAME);
    }
}
