package com.example.givemepass.commanddemo;

public class Constant {
    public final static String STANDBY_NAME = "standby";
    public final static String OPEN_NAME = "open";
    public final static String CLOSE_NAME = "close";
}
