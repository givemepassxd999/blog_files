package com.example.givemepass.commanddemo;


public class OpenCommand implements Command{
    private Computer mComputer;

    public OpenCommand(Computer mComputer) {
        this.mComputer = mComputer;
    }

    @Override
    public void execute() {
        mComputer.computerOpen();
    }

    @Override
    public String getCommandName() {
        return Constant.OPEN_NAME;
    }
}
