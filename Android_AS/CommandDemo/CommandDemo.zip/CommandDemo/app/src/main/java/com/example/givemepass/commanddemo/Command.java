package com.example.givemepass.commanddemo;

public interface Command {
    void execute();
    String getCommandName();
}
