package com.example.givemepass.commanddemo;


public class StandbyCommand implements Command{
    private Computer mComputer;

    public StandbyCommand(Computer mComputer) {
        this.mComputer = mComputer;
    }

    @Override
    public void execute() {
        mComputer.computerStandby();
    }

    @Override
    public String getCommandName() {
        return Constant.STANDBY_NAME;
    }
}
