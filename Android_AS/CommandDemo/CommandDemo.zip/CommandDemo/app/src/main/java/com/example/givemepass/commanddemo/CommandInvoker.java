package com.example.givemepass.commanddemo;

import java.util.ArrayList;
import java.util.List;

public class CommandInvoker {
    private List<Command> mCommandList;
    public CommandInvoker() {
        mCommandList = new ArrayList<>();
    }

    public void setCommand(Command cmd){
        mCommandList.add(cmd);
    }

    public void runCommand(String cmdName){
        for(Command c : mCommandList){
            if(c.getCommandName().equals(cmdName)){
                c.execute();
                break;
            }
        }
    }

    public void runAllCommand(){
        for(Command c : mCommandList){
            c.execute();
        }
    }

}
