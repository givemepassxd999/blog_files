package com.example.givemepass.commanddemo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView text;
    private Button open;
    private Button close;
    private Button standby;
    private Button all;
    private CommandInvoker invoker;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        initData();
        setListener();
    }

    private void initData() {
        Computer computer = new Computer(text);
        invoker = new CommandInvoker();
        OpenCommand openCommand = new OpenCommand(computer);
        CloseCommand closeCommand = new CloseCommand(computer);
        StandbyCommand standbyCommand = new StandbyCommand(computer);
        invoker.setCommand(openCommand);
        invoker.setCommand(closeCommand);
        invoker.setCommand(standbyCommand);
    }

    private void initView(){
        text = (TextView) findViewById(R.id.content);
        open = (Button) findViewById(R.id.open);
        close = (Button) findViewById(R.id.close);
        standby = (Button) findViewById(R.id.standby);
        all = (Button) findViewById(R.id.all_cmd);
    }

    private void setListener(){
        open.setOnClickListener(invokerListener);
        close.setOnClickListener(invokerListener);
        standby.setOnClickListener(invokerListener);
        all.setOnClickListener(invokerListener);
    }

    private View.OnClickListener invokerListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            text.setText("");
            switch (v.getId()){
                case R.id.open:
                    invoker.runCommand(Constant.OPEN_NAME);
                    break;
                case R.id.close:
                    invoker.runCommand(Constant.CLOSE_NAME);
                    break;
                case R.id.standby:
                    invoker.runCommand(Constant.STANDBY_NAME);
                    break;
                case R.id.all_cmd:
                    invoker.runAllCommand();
                    break;
            }
        }
    };
}
