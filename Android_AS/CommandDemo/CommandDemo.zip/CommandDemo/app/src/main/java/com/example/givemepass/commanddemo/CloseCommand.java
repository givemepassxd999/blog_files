package com.example.givemepass.commanddemo;

public class CloseCommand implements Command{
    private Computer mComputer;

    public CloseCommand(Computer mComputer) {
        this.mComputer = mComputer;
    }

    @Override
    public void execute() {
        mComputer.computerClose();
    }

    @Override
    public String getCommandName() {
        return Constant.CLOSE_NAME;
    }
}
