package personal.givemepass.downloadimagedemo;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;

public class MainActivity extends AppCompatActivity {
	private Button downloadBtn;
	private DownloadWebPicture loadPic;
	private Handler mHandler;
	private ProgressBar progressBar;
	private ImageView imageView;
	private final static String url = "https://dl.dropboxusercontent.com/u/24682760/Android_AS/DownloadImageDemo/monkey.png";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		progressBar = (ProgressBar) findViewById(R.id.progress_bar);
		imageView = (ImageView) findViewById(R.id.imageView);
		downloadBtn = (Button) findViewById(R.id.download_btn);
		loadPic = new DownloadWebPicture();

		mHandler = new Handler(){
			@Override
			public void handleMessage(Message msg) {
				switch(msg.what){
					case 1:
						progressBar.setVisibility(View.GONE);
						imageView.setVisibility(View.VISIBLE);
						imageView.setImageBitmap(loadPic.getImg());
						break;
				}
				super.handleMessage(msg);
			}
		};
		downloadBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				imageView.setImageBitmap(null);
				progressBar.setVisibility(View.VISIBLE);
				loadPic.handleWebPic(url, mHandler);
			}
		});

	}
}
