package personal.givemepass.dialogfragmentdemo;


import android.app.Fragment;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

	private Button show_basic_dialog;
	private Button show_alert_dialog;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		show_basic_dialog = (Button) findViewById(R.id.show_dialog);
		show_alert_dialog = (Button) findViewById(R.id.show_alert_dialog);
		show_basic_dialog.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				showDialog();
			}
		});
		show_alert_dialog.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				showAletDialog();
			}
		});
	}
	private void showDialog() {
		FragmentTransaction ft = getFragmentManager().beginTransaction();
		Fragment prev = getFragmentManager().findFragmentByTag("dialog");
		if (prev != null) {
			ft.remove(prev);
		}
		ft.addToBackStack(null);
		// Create and show the dialog.
		android.app.DialogFragment newFragment = new BasicDialogFragment();
//		newFragment.show(ft, "dialog");
		ft.add(R.id.embedded, newFragment);
		ft.commit();
	}


	private void showAletDialog(){
		FragmentTransaction ft = getFragmentManager().beginTransaction();
		Fragment prev = getFragmentManager().findFragmentByTag("dialog");
		if (prev != null) {
			ft.remove(prev);
		}
		ft.addToBackStack(null);
		android.app.DialogFragment newFragment = new AlertDialogFragment();
		newFragment.show(ft, "dialog");
	}


}
