package personal.givemepass.listviewreusedemo;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

	private ListView mListView;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		mListView = (ListView) findViewById(R.id.list);
		mListView.setAdapter(new MyAdapter());
	}

	private class MyAdapter extends BaseAdapter {
		private ArrayList<Integer> mList;

		public MyAdapter(){
			mList = new ArrayList<>();
			for(int i = 0; i < 100; i++){
				mList.add(i);
			}
		}
		@Override
		public int getCount() {
			return mList.size();
		}

		@Override
		public Object getItem(int position) {
			return null;
		}

		@Override
		public long getItemId(int position) {
			return 0;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View v = convertView;
			Holder holder;
			if(v == null){
				v = LayoutInflater.from(getApplicationContext()).inflate(R.layout.list_item, null);
				holder = new Holder();
				holder.text = (TextView) v.findViewById(R.id.text);

				v.setTag(holder);
			} else{
				holder = (Holder) v.getTag();
			}
			holder.text.setText(mList.get(position) + "");
			v.setBackgroundColor(Color.WHITE);
			if(position == 2){
				v.setBackgroundColor(Color.RED);
			}
			return v;
		}
		class Holder{
			TextView text;
		}
	}
}
