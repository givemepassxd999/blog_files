package com.givemepass.MyListView;

import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class TagView{
    Button button;
    ImageView image;
    TextView text;

    public TagView(Button button,ImageView image, TextView text){
        this.button = button;
        this.image = image;
        this.text = text;

    }

}
