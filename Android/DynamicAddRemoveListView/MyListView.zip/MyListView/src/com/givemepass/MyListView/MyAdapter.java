package com.givemepass.MyListView;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MyAdapter extends BaseAdapter {
	private LayoutInflater adapterLayoutInflater;

	private ArrayList<View> arrayList;
	public MyAdapter(Context c){
		adapterLayoutInflater = LayoutInflater.from(c);
		arrayList = new ArrayList<View>();
	}

	public void addItem(int position){
	    TagView tag;
        View view = adapterLayoutInflater.inflate(R.layout.adapter, null);

        tag = new TagView(
                (Button)view.findViewById(R.id.AdapterButton),
                (ImageView)view.findViewById(R.id.AdapterImage),
                (TextView)view.findViewById(R.id.AdapterText));
        view.setTag(tag);
        arrayList.add(view);
        tag.image.setBackgroundResource(R.drawable.icon);
        tag.button.setText("button"+arrayList.size());
        tag.text.setText("text"+arrayList.size());
	    this.notifyDataSetChanged();
	}
	public void removeItem(int position){
	    if(!arrayList.isEmpty()){
	        arrayList.remove(position);
	        this.notifyDataSetChanged();
	    }
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return arrayList.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View view, ViewGroup parent) {
		// TODO Auto-generated method stub
		return arrayList.get(position);
	}

}
