package com.givemepass.MyListView;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class MyListView extends ListActivity {

    private MyAdapter myAdapter;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list);
        myAdapter = new MyAdapter(this);
        setListAdapter(myAdapter);
    }
    /* (non-Javadoc)
     * @see android.app.Activity#onCreateOptionsMenu(android.view.Menu)
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // TODO Auto-generated method stub
        menu.add(0, Menu.FIRST, 0, "add item");
        menu.add(0, Menu.FIRST+1, 0, "remove item");
        return super.onCreateOptionsMenu(menu);

    }
    /* (non-Javadoc)
     * @see android.app.Activity#onOptionsItemSelected(android.view.MenuItem)
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // TODO Auto-generated method stub
        switch(item.getItemId()){
            case Menu.FIRST:
                myAdapter.addItem(myAdapter.getCount()+1);
                break;
            case Menu.FIRST+1:
                myAdapter.removeItem(myAdapter.getCount()-1);
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}