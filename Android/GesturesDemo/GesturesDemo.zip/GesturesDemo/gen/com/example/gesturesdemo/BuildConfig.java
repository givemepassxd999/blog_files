/** Automatically generated file. DO NOT MODIFY */
package com.example.gesturesdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}