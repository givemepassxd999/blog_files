package com.givemepass.MyListView;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MyAdapter extends BaseAdapter {
	private LayoutInflater adapterLayoutInflater;
	public MyAdapter(Context c){
		adapterLayoutInflater = LayoutInflater.from(c);

	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return 3;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View view, ViewGroup parent) {
		// TODO Auto-generated method stub
		TagView tag;
		if(view == null){
			view = adapterLayoutInflater.inflate(R.layout.adapter, null);
			tag = new TagView(
					(Button)view.findViewById(R.id.AdapterButton),
					(ImageView)view.findViewById(R.id.AdapterImage),
					(TextView)view.findViewById(R.id.AdapterText));
			view.setTag(tag);
		}
		else{
			tag = (TagView)view.getTag();
		}
		tag.image.setBackgroundResource(R.drawable.icon);
		tag.button.setText("button"+position);
		tag.text.setText("text"+position);
		return view;
	}
	public class TagView{
		Button button;
		ImageView image;
		TextView text;
		
		public TagView(Button button,ImageView image, TextView text){
			this.button = button;
			this.image = image;
			this.text = text;
			
		}
	}
}
