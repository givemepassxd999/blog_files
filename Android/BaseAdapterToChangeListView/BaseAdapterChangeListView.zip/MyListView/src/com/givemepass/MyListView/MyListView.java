package com.givemepass.MyListView;

import android.app.ListActivity;
import android.os.Bundle;

public class MyListView extends ListActivity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list);
        setListAdapter(new MyAdapter(this));
    }
}