package com.example.galleryflowdemo;


import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.LinearLayout.LayoutParams;
import android.widget.SimpleAdapter;
import android.widget.ViewSwitcher.ViewFactory;

public class MainActivity extends Activity {
	private GalleryFlow galleryFlow;
	private Integer[] images = { 
			R.drawable.cat, R.drawable.flower,
            R.drawable.hippo, R.drawable.monkey,
            R.drawable.mushroom, R.drawable.panda,
            R.drawable.rabbit, R.drawable.raccoon};
	private ImageSwitcher imageSwitcher;
    private SimpleAdapter simpleAdapter;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        galleryFlow = (GalleryFlow) findViewById(R.id.Gallery01);
        ImageAdapter adapter = new ImageAdapter(this, images);
        adapter.createReflectedImages();
        galleryFlow.setAdapter(adapter);
        
        imageSwitcher = (ImageSwitcher)findViewById(R.id.image_switcher);
        imageSwitcher.setFactory(new ViewFactory(){

            @Override
            public View makeView() {
                ImageView imageView = new ImageView(MainActivity.this);
                imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
                imageView.setLayoutParams(new ImageSwitcher.LayoutParams(LayoutParams.FILL_PARENT, 180));
                return imageView;
            }
            
        });
        imageSwitcher.setInAnimation(AnimationUtils.loadAnimation(this, android.R.anim.slide_in_left));
        imageSwitcher.setOutAnimation(AnimationUtils.loadAnimation(this, android.R.anim.slide_out_right));
        galleryFlow.setOnItemClickListener(new OnItemClickListener(){

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int position,
					long arg3) {
				// TODO Auto-generated method stub
				imageSwitcher.setImageResource(images[position]);
			}
        	
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }
}
