package com.givemepass.getphpservermessage;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class GetPhpServerMessageDemoActivity extends Activity {
    /** Called when the activity is first created. */
    private TextView textView;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        textView = (TextView)findViewById(R.id.text_view);
        GetServerMessage message = new GetServerMessage();
        String msg = message.stringQuery("http://localhost/ServerSendMsg.php");
        textView.setText("Server message is "+msg);
    }
}