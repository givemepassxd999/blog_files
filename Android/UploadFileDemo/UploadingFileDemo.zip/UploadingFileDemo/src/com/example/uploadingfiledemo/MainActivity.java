package com.example.uploadingfiledemo;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.widget.Toast;

public class MainActivity extends Activity {
	private String uploadUrl = "http://192.168.1.5/test_upload/uploadfile.php";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		SampleFileUpload fileUpload = new SampleFileUpload () ;
		Bitmap bm = BitmapFactory.decodeResource( getResources(), R.drawable.butterfly);
    	String path = Environment.getExternalStorageDirectory().toString(); 
    	File file = new File(path,"test.jpg");
    	
        try 
        {
        	OutputStream outStream = new FileOutputStream(file);
        	bm.compress(Bitmap.CompressFormat.JPEG, 100, outStream);
        	outStream.flush();
    	    outStream.close();
	        
        }
        catch (IOException e){
        	Log.e("error","file error");
        }
        String response = fileUpload.executeMultiPartRequest(uploadUrl,
        		file, file.getName(), "File Upload test jpg description") ;
        Toast.makeText(this, response, Toast.LENGTH_SHORT).show();
        
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
