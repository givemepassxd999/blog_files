package personal.givemepass.changebackgrounddemo;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity {
	private RelativeLayout mLayout;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		findViewById(R.id.my_ayout);
		mLayout = (RelativeLayout) findViewById(R.id.my_ayout);
		Resources res = this.getResources();
		Drawable drawable;
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
			drawable = res.getDrawable(R.drawable.blue, getTheme());
			mLayout.setBackground(drawable);
		} else {
			drawable = res.getDrawable(R.drawable.blue);
			mLayout.setBackgroundDrawable(drawable);
		}
	}
}
