package com.example.imagedownloader;

import android.app.ListActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;

public class MainActivity extends ListActivity  implements OnCheckedChangeListener {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RadioGroup radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        radioGroup.setOnCheckedChangeListener(this);
        
        setListAdapter(new ImageAdapter());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }
    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
    	Log.e("onCheckedChanged","onCheckedChanged");
        ImageDownloader.Mode mode = ImageDownloader.Mode.NO_ASYNC_TASK;
        
        if (checkedId == R.id.correctButton) {
        	Log.e("id","correctButton");
            mode = ImageDownloader.Mode.CORRECT;
        }else if (checkedId == R.id.randomButton) {
        	Log.e("id","randomButton");
            mode = ImageDownloader.Mode.NO_DOWNLOADED_DRAWABLE;
        }
        
        ((ImageAdapter) getListAdapter()).getImageDownloader().setMode(mode);
        ((ImageAdapter) getListAdapter()).update();
    }
}
