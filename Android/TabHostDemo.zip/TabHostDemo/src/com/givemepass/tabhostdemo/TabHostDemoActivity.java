package com.givemepass.tabhostdemo;

import android.app.TabActivity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.widget.TabHost.TabSpec;

public class TabHostDemoActivity extends TabActivity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
         
        addNewTab(this,Tab.class,"TabOne");
        addNewTab(this,TabTwo.class,"TabTwo");
        addNewTab(this,TabThree.class,"TabThree");
        
        getTabHost().setCurrentTab(0);
        getTabHost().requestFocus();
    }
    public void addNewTab(Context context, Class<?> cls, String tabName){
        Resources res = getResources();
        Intent intent = new Intent().setClass(this, cls);
        TabSpec spec = getTabHost().newTabSpec(tabName)
                .setIndicator(tabName,res.getDrawable(R.drawable.icon))
                .setContent(intent);
        getTabHost().addTab(spec);
    }
}