package com.example.expandablelistviewdemo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.ExpandableListActivity;
import android.os.Bundle;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.SimpleExpandableListAdapter;

public class ExpandableListViewDemo extends ExpandableListActivity {

	private static final String NAME = "NAME";
    private String[] lunch = {
    		"����","����","�p��"
    };
    private String[][] lunch_class = {
    		{"���׶�","���L��","�ư���","���ƶ�","�޸}��"},
    		{"���K��","�^��׵���","�_����","������","����"},
    		{"���z","���G","�ޥ�","���a","���J"}
    };
    
    private ExpandableListAdapter mAdapter;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        List<Map<String, String>> groupData = new ArrayList<Map<String, String>>();
        List<List<Map<String, String>>> childData = new ArrayList<List<Map<String, String>>>();
        for (int i = 0; i < lunch.length; i++) {
            Map<String, String> curGroupMap = new HashMap<String, String>();
            groupData.add(curGroupMap);
            curGroupMap.put(NAME, lunch[i]);
            
            List<Map<String, String>> children = new ArrayList<Map<String, String>>();
            for (int j = 0; j <lunch_class[i].length ; j++) {
                Map<String, String> curChildMap = new HashMap<String, String>();
                children.add(curChildMap);
                curChildMap.put(NAME, lunch_class[i][j]);
            }
            childData.add(children);
        }
        mAdapter = new SimpleExpandableListAdapter(
                this,
                groupData,
                android.R.layout.simple_expandable_list_item_1,
                new String[] { NAME },
                new int[] { android.R.id.text1 },
                childData,
                android.R.layout.simple_expandable_list_item_1,
                new String[] { NAME },
                new int[] { android.R.id.text1 }
                );
        setListAdapter(mAdapter);
    }

    
}
