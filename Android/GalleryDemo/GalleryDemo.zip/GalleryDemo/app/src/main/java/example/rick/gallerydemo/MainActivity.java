package example.rick.gallerydemo;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ArrayList<String> pathList = (ArrayList<String>) getGalleryPath();
        for(String path : pathList){
            Log.i("path", path);
        }
    }

    private List<String> getGalleryPath(){
        List<String> pathList = new ArrayList<String>();
        try {
            final String[] columns = {MediaStore.Images.Media.DATA,
                    MediaStore.Images.Media._ID};
            final String orderBy = MediaStore.Images.Media.DATE_ADDED;

            Cursor imagecursor = getContentResolver().query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, columns,
                    null, null, orderBy + " DESC");
            if (imagecursor != null) {
                while (imagecursor.moveToNext()) {
                    int dataColumnIndex = imagecursor.getColumnIndex(MediaStore.Images.Media.DATA);
                    String picPath = imagecursor.getString(dataColumnIndex);
                    if(picPath != null){
                        pathList.add(picPath);
                    }
                }
            }
        } catch(Exception e){
            e.printStackTrace();
        }
        return pathList;
    }
}
